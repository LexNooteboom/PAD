package info.login.v6;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class HulpSignup extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hulp_signup);
    }
}
