package info.login.v6;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

/**
 * @author Lars Sterk
 *
 */

public class EvenementAgendaActivity extends AppCompatActivity implements View.OnClickListener{


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_evenement_agenda);

        // Voeg de clickListener toe
        findViewById(R.id.buttonBurendag).setOnClickListener(this);
        findViewById(R.id.buttonOpruiming).setOnClickListener(this);
        findViewById(R.id.buttonVoetbaltoernooi).setOnClickListener(this);
        findViewById(R.id.buttonBootcamp).setOnClickListener(this);
        findViewById(R.id.buttonBuurtBBQ).setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.buttonBurendag:
                startActivity(new Intent(this, BurendagActivity.class));
                break;
            case R.id.buttonOpruiming:
                startActivity(new Intent(this, OpruimingActivity.class));
                break;
            case R.id.buttonVoetbaltoernooi:
                startActivity(new Intent(this, VoetbaltoernooiActivity.class));
                break;
            case R.id.buttonBootcamp:
                startActivity(new Intent(this, BootcampActivity.class));
                break;
            case R.id.buttonBuurtBBQ:
                startActivity(new Intent(this, BuurtBBQActivity.class));
                break;

        }
    }

}
