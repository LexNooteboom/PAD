package info.login.v6;

import android.content.Intent;
import android.nfc.Tag;
import android.support.annotation.NonNull;
import android.support.constraint.solver.widgets.Snapshot;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.sql.SQLOutput;
import java.util.HashMap;
import java.util.Map;

import info.login.v6.model.User;

public class testretrievedata extends AppCompatActivity {

    ListView II;
    ArrayAdapter<String> adapter;
    TextView a, b, c, d;
    Button btn;


            //database.getReference("Gebruikers/bf0qf0rmVLahnYMwxI2Sq0Y73782");

    FirebaseAuth mAuth;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_testretrievedata);





        mAuth = FirebaseAuth.getInstance();
        String gebruiker_id = mAuth.getCurrentUser().getUid();

        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        final FirebaseDatabase database1= FirebaseDatabase.getInstance();
        DatabaseReference ref= FirebaseDatabase.getInstance().getReference().child("Gebruikers").child(gebruiker_id);



        //        String postcode = mAuth.getCurrentUser().getEmail();




        a = (TextView) findViewById(R.id.TestTextViewGeboortedatum);
        b = (TextView) findViewById(R.id.TestTextViewNaam);
        c = (TextView) findViewById(R.id.TestTextviewPostcode);
        d = (TextView) findViewById(R.id.TestTextViewPunten);

        btn = (Button) findViewById(R.id.TestButtonShow);




        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
             //   User testretrievedata =  dataSnapshot.getValue(User.class);
                User testretrievedata = dataSnapshot.getValue(User.class);
//                Post post = dataSnapshot.getValue();
             //   User testretrievedata = dataSnapshot.getValue(User.class);
//                System.out.println(testretrievedata.Postcode);
//                a.setText(testretrievedata.Geboortedatum);

              //  String keys = dataSnapshot.child("postcode").toString();
               // a.setText(testretrievedata.Postcode);

                c.setText(testretrievedata.Postcode);
                b.setText(testretrievedata.Naam);
                c.setText(testretrievedata.Geboortedatum);
                String l = testretrievedata.Punten.toString();
                int i = Integer.parseInt(l);
                System.out.print("punten= "+ i);
                d.setText("punten = "+ i);





            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("The read failed: " + databaseError.getCode());
            }});








//
//
//
// @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                if (dataSnapshot.exists()){
//                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
//                    SignUpActivity signUpActivity = postSnapshot.getValue(SignUpActivity.class);
//                    Map<String, Object> objectMap = (HashMap<String, Object>) dataSnapshot.getValue();
//                    String Value = (String) objectMap.get("Gebruikers/Naam");
//                    Log.d("Gebruikers/Naam", "Value is:  " + Value);
//                    a.setText(Value);
//                }
//                }
//
//                @Override
//                public void onCancelled(DatabaseError databaseError) {
//
//                }
//                } ;
//
////
//
//
//
//
//
//
//            });


    }
    ;
}






















