package info.login.v6;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

//implementeert view.onclicklistener
public class HomeActivity extends AppCompatActivity implements View.OnClickListener {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_activity);

        //findViewById(R.id.textViewSignup).setOnClickListener(this);
        findViewById(R.id.Ranking).setOnClickListener(this);
        findViewById(R.id.EvenementAgenda).setOnClickListener(this);
        //findViewById(R.id.Profiel).setOnClickListener(this);
        findViewById(R.id.HelpMain).setOnClickListener(this);

    }
    @Override
    //onclick viewview heroept de onclick listener.
    public void onClick(View view) {
        //Switch statement die heeft meerdere nogelijkheden. Switch statements werken met cases. Als een case wordt herroepen switch hij naar die case.
        switch (view.getId()){
            //als er op de button Ranking wordt geclickt dan er een nieuwe Activity geexuceteerd.
            case R.id.Ranking:
                startActivity(new Intent(this, RankingActivity.class));
                //startActivity(new Intent(this, HomeActivity.class));
                //stoppen met de uitvoering.
                break;

            case R.id.HelpMain:
                startActivity(new Intent(this, HelpMainActivity.class));
               break;
            case R.id.EvenementAgenda:
                startActivity(new Intent(this, EvenementAgendaActivity.class));
                break;
            //case R.id.Profiel:
            //    startActivity(new Intent(this, ProfielActivity.class));
            //    break;

        }




    }
}
