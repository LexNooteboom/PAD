package info.login.v6.model;

import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class User {

    public String Postcode;
    public String Naam;
    public String Geboortedatum;
   // public String Punten;
    public Long Punten;

    public User() {
        // Default constructor required for calls to DataSnapshot.getValue(User.class)
    }

    public User(String Naam, String Postcode, Long Punten, int Intpunten  ) {
        this.Geboortedatum = Geboortedatum;
        this.Postcode = Postcode;
        this.Naam= Naam;
        this.Punten = Punten;

        //        this.Naam = Naam;
//        this.Punten= punten;


    }
    public String get_Naam(){
        return Naam;
    }



}