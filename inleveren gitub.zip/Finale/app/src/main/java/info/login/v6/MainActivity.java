package info.login.v6;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    FirebaseAuth mAuth;
    EditText editTextEmail, editTextPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();

        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);

        //defineren van een knop
        findViewById(R.id.textViewSignup).setOnClickListener(this);
        findViewById(R.id.buttonLogin).setOnClickListener(this);
        findViewById(R.id.buttonHelpLogin).setOnClickListener(this);
    }

    private void userLogin() {
        //hier wordt gedefineerd er in moet
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        if (email.isEmpty()) {
            editTextEmail.setError("Email is required");
            //dit zorgt er voor dat elke input  'gehoord' wordt
            editTextEmail.requestFocus();
            return;
        }
        //kijkt of het email klopt (volgens het email pattern)
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            editTextEmail.setError("Wrong Email");
            editTextEmail.requestFocus();
            return;
        }
        //checkt of er iets is ingevuld in het wachtwoord
        if (password.isEmpty()) {
            editTextPassword.setError("Password is required");
            editTextPassword.requestFocus();
            return;
        }
        //kijkt of het wachtwoord lager is dan 6 karakters
        if (password.length() < 6) {
            editTextPassword.setError("Minimum length of password is 6");
            editTextPassword.requestFocus();
            return;
        }
        //inloggen met email en password mAuth connectie met firebase
            mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()){
                    Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                    //zorgt dat je niet meer terug kan klikken als je ingelogt bent
                    intent.addFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    }else{
                        //toast kleine android popup
                        Toast.makeText(getApplicationContext(), task.getException(). getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

//hier worden de buttons gekoppeld aan de acties die ze moeten doen.
        @Override
        public void onClick (View view){
            switch (view.getId()) {
                case R.id.textViewSignup:

                    startActivity(new Intent(this, SignUpActivity.class));
                    break;

                case R.id.buttonHelpLogin:
                    startActivity(new Intent(this, HelpLogin.class));
                    break;

                case R.id.buttonLogin:
                    userLogin();
                    break;



            }
        }
    }
