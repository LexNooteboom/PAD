package info.login.v6;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

import info.login.v6.model.User;
/**
 * @author Lars Sterk
 *
 * Evenementen pagina met inschrijf button
 */
public class OpruimingActivity extends AppCompatActivity implements View.OnClickListener {

    // Attributen
    private FirebaseAuth mAuth;
    DatabaseReference refEvenement;
    DatabaseReference refNaam;
    private Button buttonAdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_opruiming);

        // Database connectie
        mAuth = FirebaseAuth.getInstance();
        String gebruiker_id = mAuth.getCurrentUser().getUid();

        // Database references
        refNaam = FirebaseDatabase.getInstance().getReference().child("Gebruikers").child(gebruiker_id);
        refEvenement = FirebaseDatabase.getInstance().getReference("Evenement inschrijver").child("Opruiming");

        Button buttonOpruiming = findViewById(R.id.buttonOpruiming);
        buttonOpruiming.setOnClickListener(this);

        // Locate de button
        buttonAdd = (Button) findViewById(R.id.inschrijfButtonOpruiming);


        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Datasnapshot om de Naam te kunnen weergeven
                refNaam.addValueEventListener(new ValueEventListener() {
                    @Override

                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        User testretrievedata = dataSnapshot.getValue(User.class);

                        String naam;
                        naam = testretrievedata.Naam;

                        // 1 - Maak de child in het root object
                        // 2 - Geef een waarde aan de child object

                        // Hashmap om de naam te printen
                        Map newPost = new HashMap();


                        newPost.put("Naam inschrijver", naam);

                        refEvenement.child("Inschrijvers").child(gebruiker_id).setValue(newPost);

                    }


                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        System.out.print("Error");

                    }
                });

        }





    });


}


    @Override
    public void onClick(View view){

        switch (view.getId()){
            //WANNEER IEMAND OP DE BUTTON 'HELP' KLIKT WORD DE HELP PAGINA VAN RANKING GEOPEND
            case R.id.buttonOpruiming:
                startActivity(new Intent(this, OpruimingHelp.class));

                break;


        }

    }
}
