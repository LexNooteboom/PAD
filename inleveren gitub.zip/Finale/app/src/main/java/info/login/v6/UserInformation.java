package info.login.v6;

public class UserInformation {
    private String username;
    private String email;
    private String password;


    public UserInformation(){

    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getE() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }




}
