package info.login.v6;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.common.server.converter.StringToIntConverter;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class SignUpActivity extends AppCompatActivity implements View.OnClickListener {
    //geeft aan dat dese text ingevuld moet worden.
    EditText editTextEmail, editTextPassword, editTextGeboortedatum, editTextNaam; //editTextPostcode;
    int punten = 0;

    private FirebaseAuth mAuth;

    @Override
    //protected void is dat deze void beschermt is en alleen usable is in deze class of een gerelateerde class.
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
    //geef waardes aan de buttons.
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);
        editTextNaam = findViewById(R.id.editTextNaam);
        editTextGeboortedatum = findViewById(R.id.editTextGeboortedatum);
        //editTextPostcode = findViewById(R.id.editTextPostcode);
    //roept firebase aan
        mAuth = FirebaseAuth.getInstance();
    //Zet  de 'knop' op de knop zodat je er op kan klikken. This verwijst naar buttonSignup.
        findViewById(R.id.buttonSignUp).setOnClickListener(this);
        //findViewById(R.id.textViewSignup).setOnClickListener(this);
        findViewById(R.id.textViewLogin).setOnClickListener(this);
        findViewById(R.id.buttonHelpSignup).setOnClickListener(this);

    }
    //private void betekent dat alleen de methodes van deze class toegang hebben tot de members.
    private void registerUser() {
        //zorgt ervoor dat je text kan invoeren. met getText weet hij dat er text moet komen to string betekent dat het een string format moet zijn en trim elimineert de spaties aan het begin of eind.
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        if (email.isEmpty()) {
            editTextEmail.setError("Email is required");
            //requestfocus zorgt er voor dat er bij elke input wordt geluisterd bij de respective listener component. in dit geval editTextMail.
            editTextEmail.requestFocus();
            return;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            editTextEmail.setError("Wrong Email");
            //requestfocus zorgt er voor dat er bij elke input wordt geluistert bij de respective listener component. in dit geval editTextMail.
            editTextEmail.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            editTextPassword.setError("Password is required");
            //requestfocus zorgt er voor dat er bij elke input wordt geluisterd bij de respective listener component. in dit geval editTextPassword.
            editTextPassword.requestFocus();
            return;
        }
        if (password.length() < 6) {
            editTextPassword.setError("Minimum length of password is 6");
            //requestfocus zorgt er voor dat er bij elke input wordt geluisterd bij de respective listener component. in dit geval editTextPassword.
            editTextPassword.requestFocus();
            return;

        }
        //roept de methode aan van google firebase. om mensen te laten inloggen en registreren via email en password.
        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {

                    //Toast maakt kleine android popup. Length short is de duratie hoe lang de popup blijft staan
                    Toast.makeText(getApplicationContext(), "User Registered Successfull", Toast.LENGTH_SHORT).show();

                    //Maakt een string van de currect user ID van firebase. getUid = get user ID
                    String gebruiker_id = mAuth.getCurrentUser().getUid();

                    //Refereert naar de database. De app weet de database te vinden via FIrebaseDatabase.getInstance(). En pakt gelijk de referencies. De .child zijn child tabels van de database
                    DatabaseReference current_gebruiker_db = FirebaseDatabase.getInstance().getReference().child("Gebruikers").child(gebruiker_id);

                    //Maak een string van de ingevoerde text voor Map newpost.
                    String naam = editTextNaam.getText().toString();
                    String geboortedatum = editTextGeboortedatum.getText().toString();
                    //String postcode = editTextPostcode.getText().toString();

                    if (punten < 5){
                        punten = 0;
                    }

                    //Map newpost zorgt er voor dat alles tegelijke tijd wordt geupload in de database
                    //Hashmap is een hash tabel gebaseerd op java'smap interface met een collectie of key-value pairs. In dit geval zijn dat "naam", naam etc. dit zorgt er voor dat er geen gedupliceerde keys kunnen zijn
                    Map newPost = new HashMap();
                    newPost.put("Naam", naam);
                    newPost.put("Geboortedatum", geboortedatum);
                    //newPost.put("Postcode", postcode);
                    newPost.put("Punten", punten);
                    newPost.put("Gebruiker_UUID", gebruiker_id);
                    //Update de values in de database
                    current_gebruiker_db.setValue(newPost);

                    //Start een nieuwe activity. van SignupActivity naar HomeActivity
                    Intent intent = new Intent(SignUpActivity.this, HomeActivity.class);
                    //Zou er voor moeten zorgen dat je niet terug naar de signup activity kan als je eenmaal in de homeactivity zit.
                    intent.addFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);
                    //Begint met de nieuwe activity.
                    startActivity(intent);

                } else {
                    //task.getexception zijn bijzonderheden. FirebaseAuthusercollisionException betekent dat de user al geregistreerd is.
                    //LENGTH_SHORT is de duratie hoelang de toast (android pop-up) gedisplayed is.
                    if(task.getException() instanceof FirebaseAuthUserCollisionException){
                        Toast.makeText(getApplicationContext(), "You are already registered", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getApplicationContext(), task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    @Override
    //onclick viewview heroept de onclick listener.
    public void onClick(View view) {
        //Switch statement die heeft meerdere nogelijkheden. Switch statements werken met cases. Als een case wordt herroepen switch hij naar die case.
        switch (view.getId()) {
            //als er op de buttonSignup wordt geclickt dan exuceert bij de registerUser.
            case R.id.buttonSignUp:
                registerUser();
                //nadat de registeruse is herroepen moet hij stoppen met break.
                break;

            case R.id.textViewLogin:
               //Als de case textViewLogin wordt herroepen dan start bij  een nieuwe activity.
                startActivity(new Intent(this, MainActivity.class));
                break;
            case R.id.buttonHelpSignup:
                startActivity(new Intent(this, HulpSignup.class));
                break;


        }
    }
}

