package info.login.v6;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.Normalizer;
import java.util.Timer;
import java.util.TimerTask;

import info.login.v6.R;
import info.login.v6.model.HelpRanking;
import info.login.v6.model.User;


public class RankingActivity extends AppCompatActivity implements View.OnClickListener {

    ProgressBar pb;

    int behaaldePunten;
    int showPunten;
    int counter = 0;

    TextView levelNaam;
    FirebaseAuth mAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ranking);
        ShowPunten();
        //progressbar
        int pbPunten;
        pb = (ProgressBar) findViewById(R.id.pb);
        pb.setProgress(showPunten);

        //database
        mAuth = FirebaseAuth.getInstance();
        //GEBRUIKDER_ID IS DE HUIDIGE GEBRUIKER
        String gebruiker_id = mAuth.getCurrentUser().getUid();
        //REF MAKEN NAAR DE GEBRUIKER DIE NU OP DE APP ZIT
        DatabaseReference ref= FirebaseDatabase.getInstance().getReference().child("Gebruikers").child(gebruiker_id);



        //TEXTVIEW EN BUTTONS WORDEN GEIDENTIFICEERD
        levelNaam = (TextView) findViewById(R.id.levelNaam);
        TextView punten = (TextView) findViewById(R.id.puntenText);
        TextView hoeveelheidPunten= (TextView) findViewById(R.id.puntenVoortgangTekst);
        Button testButton = (Button) findViewById(R.id.buttonTotaalBehaaldePunten);
        Button buttonBack= (Button) findViewById(R.id.buttonBack);

        getLevelNaam();



        buttonBack.setOnClickListener(this);





        // Lambda
//        testButton.setOnClickListener(event -> {
//
//            behaaldePunten += 20;
//            Log.i("TAG", Integer.toString(behaaldePunten));
//            punten.setText(Integer.toString(behaaldePunten));
//            pb.setProgress(showPunten);
//            hoeveelheidPunten.setText(showPunten+"/"+"100");
//            pb.setMax(90);
//            getLevelNaam();
//            ShowPunten();
//
//        });



        //(40/100)aantal behaalde punten weergeven
        //  hoeveelheidPunten.setText(showPunten+"/"+"100");


        //totaalbehaalde punten weergeven
//        punten.setText(Integer.toString(behaaldePunten));


        //MAAKT
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                //HAALT DE DATA VAN DE GEBRUIKER OP UIT DE USER.CLASS
                User testretrievedata = dataSnapshot.getValue(User.class);

                //VOOR PUNTEN WORD VAN VAN EEN LONG EEN STRING GEMAAKT, EN DAARNA VAN EEN STRING EEN INT
                String l = testretrievedata.Punten.toString();
                int i = Integer.parseInt(l);

                behaaldePunten= i;
                //GEEFT SHOWPUNTEN NEER VOOR DE PROGRESS BAR
                ShowPunten();

                //PAST LEVELNAAM AAN
                getLevelNaam();

                //SHOWPUNTEN GEEFT DE PROGRESS BAR WEER
                pb.setProgress(showPunten);

                hoeveelheidPunten.setText(showPunten+"/"+"100");
                punten.setText(" "+behaaldePunten);



            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }
    //snelheid van het balkje
    public void prog(){
        pb = (ProgressBar) findViewById(R.id.pb);

        final Timer t = new Timer();
        TimerTask tt = new TimerTask() {
            @Override
            public void run() {

                counter++;
                pb.setProgress(counter);

                if (counter == behaaldePunten) {
                    t.cancel();
                }
            }

        };

        tt.run();
    }


    //levelniveau aanpassen DOOR TE KIJKEN HOEVEEL PUNTEN EEN GEBRUIKER HEEFT
    public TextView getLevelNaam() {


        if (behaaldePunten < 100) {
            levelNaam.setText("BEGINNER");

        }
        //2e level
        else if (behaaldePunten >= 100 && behaaldePunten < 200) {
            levelNaam.setText("GEVORDERD");
        }
        //3e level
        else if (behaaldePunten >= 200 && behaaldePunten < 300) {
            levelNaam.setText("BAAS");
        }
        //4e level
        else if (behaaldePunten >= 300 && behaaldePunten < 400) {
            levelNaam.setText("SUPER BAAS ");
        }
        //4e level
        else if (behaaldePunten >= 400 && behaaldePunten < 500) {
            levelNaam.setText("SUPER SUPER BAAS");
        }
        return levelNaam;
    }

    //laat progressbarr opnieuw beginnen. DOOR STEEDS MINDER PUNTEN DAN 100 TE HEBBEN
    public int ShowPunten() {


        if (behaaldePunten<100){
            showPunten=behaaldePunten;
        }

        if (behaaldePunten>=100 && behaaldePunten<=200){
            showPunten=behaaldePunten-100;
        }
        if  (behaaldePunten>=200 && behaaldePunten<=300) {
            showPunten = behaaldePunten - 200;
        }
        if  (behaaldePunten>=300 && behaaldePunten<=400) {
            showPunten = behaaldePunten - 300;
        }
        return showPunten;}

    @Override
    public void onClick(View view){

        switch (view.getId()){
            //WANNEER IEMAND OP DE BUTTON 'HELP' KLIKT WORD DE HELP PAGINA VAN RANKING GEOPEND
            case R.id.buttonBack:
                startActivity(new Intent(this, HelpRanking.class));

                break;


        }

    }

}
